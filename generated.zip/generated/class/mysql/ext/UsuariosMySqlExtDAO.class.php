<?php
/**
 * Class that operate on table 'usuarios'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2015-09-16 01:46
 */
class UsuariosMySqlExtDAO extends UsuariosMySqlDAO{

	
}
?>