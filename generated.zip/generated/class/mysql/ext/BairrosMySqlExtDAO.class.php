<?php
/**
 * Class that operate on table 'bairros'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2015-09-16 01:45
 */
class BairrosMySqlExtDAO extends BairrosMySqlDAO{

	
}
?>