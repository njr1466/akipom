<?php
/**
 * Class that operate on table 'clientes'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2015-09-16 00:57
 */
class ClientesMySqlExtDAO extends ClientesMySqlDAO{

	
}
?>