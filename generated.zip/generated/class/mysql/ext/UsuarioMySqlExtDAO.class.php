<?php
/**
 * Class that operate on table 'usuario'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2015-09-16 00:57
 */
class UsuarioMySqlExtDAO extends UsuarioMySqlDAO{

	
}
?>