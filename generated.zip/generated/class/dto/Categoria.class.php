<?php
	/**
	 * Object represents table 'categorias'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 01:45	 
	 */
	class Categoria{
		
		var $id;
		var $nome;
		var $descricao;
		
	}
?>