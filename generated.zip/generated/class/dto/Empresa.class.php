<?php
	/**
	 * Object represents table 'empresas'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 01:45	 
	 */
	class Empresa{
		
		var $id;
		var $empresa;
		var $cnpj;
		var $inscricao;
		var $endereco;
		var $bairro;
		var $cidade;
		var $cep;
		var $uf;
		
	}
?>