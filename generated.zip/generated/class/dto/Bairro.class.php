<?php
	/**
	 * Object represents table 'bairros'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 01:45	 
	 */
	class Bairro{
		
		var $id;
		var $idCidade;
		var $bairro;
		
	}
?>