<?php
	/**
	 * Object represents table 'clientes'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 00:56	 
	 */
	class Cliente{
		
		var $id;
		var $nome;
		var $sobrenome;
		var $email;
		var $senha;
		var $ativo;
		
	}
?>