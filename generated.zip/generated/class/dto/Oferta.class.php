<?php
	/**
	 * Object represents table 'ofertas'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 01:45	 
	 */
	class Oferta{
		
		var $id;
		var $idCliente;
		var $idCategoria;
		var $promocao;
		var $valorantigo;
		var $valor;
		var $desconto;
		var $qtd;
		var $datainicial;
		var $datafinal;
		var $descricao;
		var $foto1;
		var $foto2;
		var $foto3;
		var $mapa;
		var $ativo;
		var $principal;
		
	}
?>