<?php
	/**
	 * Object represents table 'usuarios'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2015-09-16 01:45	 
	 */
	class Usuario{
		
		var $id;
		var $nome;
		var $sobrenome;
		var $email;
		var $sexo;
		var $uf;
		var $cidade;
		var $bairro;
		var $telefone;
		var $idFacebook;
		var $senha;
		var $ativo;
		
	}
?>